"""Public analysis use cases."""
