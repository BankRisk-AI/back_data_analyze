"""Public analysis API."""
